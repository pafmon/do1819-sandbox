const http = require('http');
const {
    promiseSerial,
    promiseParallel
} = require('./promiseUtils');
const {
    getBegin,
    getDuration
} = require('./timeUtils');


if (process.argv.length != 6) {
    console.log("Use %s %s <concurrentUsers> <iterations> <delay in ms> <url>", process.argv[0], process.argv[1]);
    process.exit();
}


concurrentUsers = process.argv[2] || 2;
iterations = process.argv[3] || 3;
delay = process.argv[4] || 500;
url = process.argv[5] || 'http://knapsack-api.herokuapp.com/api/v1/stress/10000/10';
//url = process.argv[5] || 'http://localhost:8080/api/v1/stress/10000/10';

console.log("Stress configuration:");
console.log("  - Concurrent users: %d", concurrentUsers);
console.log("  - Iterations: %d", iterations);
console.log("  - Delay: %d", delay);
console.log("  - URL: <%s>", url);

process.stdout.write("Stressing");

function computeLotStats(stats) {
    return {
        "stats": stats,
        "summary": {
            "count": stats.length,
            "avg": stats.reduce((r, n) => {
                return r + n.completeResponseTime;
            }, 0) / stats.length,
            "min": stats.reduce((r, n) => {
                return ((r > n.completeResponseTime) ? n.completeResponseTime : r);
            }, 1000000),
            "max": stats.reduce((r, n) => {
                return ((r < n.completeResponseTime) ? n.completeResponseTime : r);
            }, 0),
        }
    };
}


function computeFullStats(stats) {

    var statsCount = stats.reduce((r, n) => {
        return r + n.result.summary.count;
    }, 0);

    var fullStats = {
        "lotStats": stats,
        "summary": {
            "count": statsCount,
            "avg": stats.reduce((r, n) => {
                return r + n.result.summary.avg;
            }, 0) / stats.length,
            "min": stats.reduce((r, n) => {
                return ((r > n.result.summary.min) ? n.result.summary.min : r);
            }, 1000000),
            "max": stats.reduce((r, n) => {
                return ((r < n.result.summary.max) ? n.result.summary.max : r);
            }, 0),
        }
    };
    return fullStats;
}

//function createRequestPromise(id, url, delay) {
function createRequestPromise(id, url) {
    return new Promise(function (resolve, reject) {
        var stats = {
            "id": id,
            "initialResponseTime": 0.0,
            "completeResponseTime": 0.0
        };
        //console.log("Request to <%s>...", url);

        var begin = getBegin();

        http.get(url, (resp) => {

            let data = '';

            stats["initialResponseTime"] = getDuration(begin);


            // A chunk of data has been recieved.
            resp.on('data', (chunk) => {
                data += chunk;
            });

            // The whole response has been received. Print out the result.
            resp.on('end', () => {
                stats["completeResponseTime"] = getDuration(begin);
                resolve(stats)
                //setTimeout(resolve, delay, stats);
            });

        }).on("error", (err) => {
            reject(err);
        });
    });
}

var requestPromiseParams = [];
for (var i = 1; i <= concurrentUsers; i++) {
    requestPromiseParams.push({
        "id": "user" + i,
        "url": url
    });
}


const requestPromises = requestPromiseParams.map(param => () => createRequestPromise(param["id"], param["url"]));

function showStats(stats) {
    var fullStats = {
        "stats": stats,
        "summary": {
            "count": stats.length,
            "avg": stats.reduce((r, n) => {
                return r + n.completeResponseTime;
            }, 0) / stats.length,
            "min": stats.reduce((r, n) => {
                return ((r > n.completeResponseTime) ? n.completeResponseTime : r);
            }, 1000000),
            "max": stats.reduce((r, n) => {
                return ((r < n.completeResponseTime) ? n.completeResponseTime : r);
            }, 0),
        }
    };
    console.log("Result:" + JSON.stringify(fullStats, null, 2));
}

function createRequestLotPromise(iteration, harvester) {
    return new Promise(function (resolve, reject) {

        promiseParallel(requestPromises)
            .then((results) => {
                var requestLotResult = {
                    "id": iteration,
                    "result": computeLotStats(results)
                };
                harvester(requestLotResult);
                resolve(requestLotResult);
            })
            .catch(reject);
    });
}

var remainingIterations = iterations;

var iterationResults = [];


function requestLot(it, harvester) {
    createRequestLotPromise(it, harvester).catch((err) => {
        console.error(it+" : "+err);
        remainingIterations--;
        console.error("Remaining Iterations:"+remainingIterations);
        if (iterationResults.length >= remainingIterations) {
            console.log("\nResult:");
            console.log(JSON.stringify(computeFullStats(iterationResults).summary, null, 2));
        }
    });
}

for (var i = 1; i <= iterations; i++) {
    setTimeout(requestLot, (delay * (i - 1)), "iteration" + i, harvester);
}

process.stdout.write(":\n");

function harvester(iterationResult) {
   
    iterationResults.push(iterationResult);
    var completedIterations = iterationResults.length;    

    console.log("  - %s completed (%d/%d of %d)", iterationResult.id,completedIterations,remainingIterations, iterations);
    //process.stdout.write(".");
    
    if (completedIterations >= remainingIterations) {
        console.log("\nResult:");
        console.log(JSON.stringify(computeFullStats(iterationResults).summary, null, 2));
    }
};
