# api-requester
Usage: `node index <concurrentUsers> <iterations> <delay in ms> <url>`

Examples:
```terminal
node .\index.js 10 20 100 http://knapsack-api.herokuapp.com/api/v1/stress/10000/10
node .\index.js 10 20 100 http://localhost:8080/api/v1/stress/10000/10

```
